Para ganar necesita llegar a 7000 puntos.
Si muere puede empezar desde el principio.
Para moverse se usan las teclas de direccion y para atacar con espacio.